# Agent Bundle: Bundle Test Agent

**Agent ID**: bundle_test
**Role**: Testing Bundles
**Created**: 2025-09-05T07:24:27.764Z

## Contents
- bundle_test_manifest.json - Agent configuration and metadata

## Usage
This bundle contains all necessary files for deploying the Bundle Test Agent agent.
Refer to the manifest file for integration configurations and governance settings.
